Readme for IntechOpen Authoring Template.

The first release IntechOpen-Book.cls (version 0.1) and latex template includes following files:

********************************** Files **********************************

README.txt                   - This file.

User-manual.pdf              - The user manual for how to work with templates

Template/IntechOpen-Book.cls - The IntechOpen Authoring template class file

Sample/IntechOpen-Book.pdf - A sample output for reference

Sample/IntechOpen-Book.tex - The main file of latex template

***************************************************************************
